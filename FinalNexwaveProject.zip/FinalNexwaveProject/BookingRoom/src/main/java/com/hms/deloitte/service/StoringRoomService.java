package com.hms.deloitte.service;

import java.util.List;

import com.hms.deloitte.model.StoringRoom;

public interface StoringRoomService {
	
	//public void  incrementRoom(StoringRoom storingRoom);
	public void  incrementRoom(int roomType);
	public void  decrementRoom(int roomType);
	public List<StoringRoom> listRooms();
	public int totamnt();
	public void reset();
	
}
