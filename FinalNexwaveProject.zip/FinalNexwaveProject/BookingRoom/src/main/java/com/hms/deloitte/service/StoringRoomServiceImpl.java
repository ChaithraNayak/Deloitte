package com.hms.deloitte.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hms.deloitte.dao.StoringRoomDAO;
import com.hms.deloitte.model.StoringRoom;




@Service
public class StoringRoomServiceImpl implements StoringRoomService{


	@Autowired
	StoringRoomDAO storingRoomDAO;

	@Override
	@Transactional
	
	public void incrementRoom(int roomType) {
		
		StoringRoom storingRoom = new StoringRoom();
		Optional<StoringRoom> storingRoom1 = storingRoomDAO.findByRoomType(roomType);
		
		storingRoom = storingRoom1.get();
	
		if(storingRoom.noOfRooms>0)
		{
			storingRoom.noOfRooms--;
			storingRoom.selected++;
			storingRoom.totalPrice = storingRoom.selected * storingRoom.getPrice();
		}
		
	}
	

	@Override
	@Transactional
	public void decrementRoom(int roomType) {
		
		StoringRoom storingRoom = new StoringRoom();
		Optional<StoringRoom> storingRoom1 = storingRoomDAO.findByRoomType(roomType);
		
		storingRoom = storingRoom1.get();
	
		if(storingRoom.noOfRooms<10)
			
		{
				storingRoom.noOfRooms++;
				storingRoom.selected--;
				storingRoom.totalPrice = storingRoom.selected * storingRoom.getPrice();
		}
	}
	@Override
	@Transactional
	public List<StoringRoom> listRooms() {
		return (List<StoringRoom>) this.storingRoomDAO.findAll();
		
	}

	public int totamnt()
	{
	
		StoringRoom storingRoom = new StoringRoom();
		Optional<StoringRoom> storingRoom1 =storingRoomDAO.findByRoomType(11);
		int amt=0;
		if(storingRoom1.isPresent())
		{
			storingRoom = storingRoom1.get();
			amt+= storingRoom.getTotalPrice();
		}
		else
			return 0;
		StoringRoom storingRoom2 = new StoringRoom();
		Optional<StoringRoom> storingRoom3 =storingRoomDAO.findByRoomType(12);
		if(storingRoom3.isPresent())
		{
			storingRoom2 = storingRoom3.get();
			amt+= storingRoom2.getTotalPrice();
		}
		else
			return 0;
		StoringRoom storingRoom4 = new StoringRoom();
		Optional<StoringRoom> storingRoom5 =storingRoomDAO.findByRoomType(21);
		if(storingRoom5.isPresent())
		{
			storingRoom4 = storingRoom5.get();
			amt+= storingRoom4.getTotalPrice();
		}
		else
			return 0;
		StoringRoom storingRoom6 = new StoringRoom();
		Optional<StoringRoom> storingRoom7 =storingRoomDAO.findByRoomType(22);
		if(storingRoom7.isPresent())
		{
			storingRoom6 = storingRoom7.get();
			amt+= storingRoom6.getTotalPrice();
		}
		else
			return 0;
		return amt;
	}


	@Override
	public void reset() {
		// TODO Auto-generated method stub
		StoringRoom storingRooms = new StoringRoom();
		Optional<StoringRoom> storingRoomss =storingRoomDAO.findByRoomType(22);
		if(storingRoomss.isPresent())
		{
			storingRooms = storingRoomss.get();
			storingRooms.totalPrice=0;
			storingRooms.selected=0;
			storingRooms.noOfRooms=10;
		}
		StoringRoom storingRooms1 = new StoringRoom();
		Optional<StoringRoom> storingRoomss2 =storingRoomDAO.findByRoomType(12);
		if(storingRoomss2.isPresent())
		{
			storingRooms1 = storingRoomss2.get();
			storingRooms1.totalPrice=0;
			storingRooms1.selected=0;
			storingRooms1.noOfRooms=10;
		}
		StoringRoom storingRooms3 = new StoringRoom();
		Optional<StoringRoom> storingRoomss4 =storingRoomDAO.findByRoomType(21);
		if(storingRoomss4.isPresent())
		{
			storingRooms3 = storingRoomss4.get();
			storingRooms3.totalPrice=0;
			storingRooms3.selected=0;
			storingRooms3.noOfRooms=10;
		}
		StoringRoom storingRooms5 = new StoringRoom();
		Optional<StoringRoom> storingRoomss6 =storingRoomDAO.findByRoomType(11);
		if(storingRoomss6.isPresent())
		{
			storingRooms5 = storingRoomss6.get();
			storingRooms5.totalPrice=0;
			storingRooms5.selected=0;
			storingRooms5.noOfRooms=10;
		}
		
	}

}
