
public class PrintMessage {

	public static void main(String[] args) 
	{
		System.out.println("Hello and welcome to IDE");
		Customer c = new Customer();
		c.customer();
	}

}
