package org.animals;

public class Monkey {

	public String color = "grey";
	public int weight=50;
	public int age=80;
	
	public void likeisVegetarian()
	{
		System.out.println("Monkey is a Vegetarian");
		
	}
	
	public void canClimb()
	{
		System.out.println("Moneky can climb");
		
	}
	
	public void getSound()
	{
		System.out.println("Monkey sound");
	}
}
