package org.animals;

public class Lion {

	 public String color="Yellow";
	 public int weight=100;
	 public int age=90;
	
	public void likeisVegetarian()
	{	 
		System.out.println("Lionn is not a Vegetarian");
		
	}
	
	public void canClimb()
	{
		System.out.println("Lion Cannot climb");
		
	}
	
	public void getSound()
	{
		System.out.println("Lion sound");
	}
}
