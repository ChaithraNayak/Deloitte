
public class Employee 
{
	public void employee()
	{
		System.out.println("Lets call employee class");
	}
}
