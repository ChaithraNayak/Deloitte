package exception;

public class TryHandle {
	int i=0;
	
	public void check()
	{
		try 
		{
			i=10/0;
		}
		catch(Exception e)
		{
			System.out.println("Exception occured");
		}
		System.out.println("Value of i is :"+i);
	}
	public static void main(String[] args) {
		TryHandle h1= new TryHandle();
		h1.check();
	}
}
