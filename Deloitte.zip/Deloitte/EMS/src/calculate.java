import java.util.Scanner;

public class calculate {
	int  i;
	public void dis()
	{
		int j;
		//System.out.println(i+j);
	}
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter two numbers.");
	int num1 = sc.nextInt();
	int num2= sc.nextInt();
	float skjd=4;
	System.out.println(skjd);
	
	int sum;
	
	sum=num1+num2;
	if(sum<0)
		 System.out.println("Sum less than 0");
	else 
		System.out.println("Sum is : "+sum);
	calculate c= new calculate();
	c.dis();
	
	
}
}
