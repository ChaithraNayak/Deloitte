package access2;

import access1.A;

public class D {
	
	public void display()
	{
		A a = new A();
		//a.i= 100;
		//i=200;
	}
}
