package co.abs;


abstract class Hippo extends Animal{
	
	abstract void makeNoise();
	//abstract void eat();
	
	public void eat() {
		System.out.println("Hippo animal eats");
	};

}