package co.abs;

abstract class Feline extends Animal{
	abstract void makeNoise();
	abstract void eat();
	
	public void roam() {
		System.out.println("Canine Class animal roams");
	};

}

class Lion extends Feline
{
	public void makeNoise() {}
	public void eat() {}
}

class Tiger extends Feline
{
	public void makeNoise() {}
	public void eat() {}
}

class Cat extends Feline
{
	public void makeNoise() {}
	public void eat() {}
}
