package co.test;

public class Animal {
	public void eat()
	{
		System.out.println("Animal eats");
	}
	public void talk()
	{
		System.out.println("Animal talks");
	}

}
