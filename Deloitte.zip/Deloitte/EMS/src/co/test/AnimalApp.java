package co.test;

public class AnimalApp {
	public static void main(String[] args) {
		Animal a1= new Animal();
		a1.eat();
		a1.talk();
		Cat c = new Cat();
		c.eat();
		c.talk();
	}
}
