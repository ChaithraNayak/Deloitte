package co.file;

import java.io.FileReader;
import java.io.IOException;

public class Reading {
	public static void main(String[] args) throws IOException {
		FileReader fr = new FileReader("C:\\Deloitte\\Batch\\BatchBatchMates.txt");
		int i=0;
		while((i=fr.read())!=-1)
		{

			System.out.println((char)i);
		}
		fr.close();
	}
}
