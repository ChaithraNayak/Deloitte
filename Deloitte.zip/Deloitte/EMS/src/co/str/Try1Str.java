package co.str;

class Check2
{

	public void method1()
	{
		
	}
	@Override
	protected void finalize() throws Throwable {
		System.out.println("Garbage 2 Collection inititated");
		System.gc();
		System.out.println("gc callled again");
	}

}

class Check
{
	@Override
	protected void finalize() throws Throwable {
		System.out.println("Garbage 1 Collection inititated");
	}
	
}

public class Try1Str {
	
	
	public static void main(String[] args) 
	{
		Check t1 = new Check();
		
		System.out.println("Object created");
		
		
		Check2 t2= new Check2();
		//t2.method1();
		t2=null;
		t1=null;
		System.gc();
	}

}
