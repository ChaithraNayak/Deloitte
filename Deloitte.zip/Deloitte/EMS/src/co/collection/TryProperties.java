package co.collection;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class TryProperties {
	public static void main(String[] args) throws IOException {
		Properties property = new Properties();
		FileReader reader = new FileReader("C:\\Deloitte\\CollectionFiles\\src\\key.properties");
		
		property.load(reader);
		
		System.out.println(property.get("user1"));
		System.out.println(property.get("user2"));
		System.out.println(property.get("user3"));
	}

}
