package co.collection;

import java.util.Hashtable;
import java.util.Map;

public class Trymap {
	public static void main(String[] args) {
		
	
	Map<Integer,String> data1 =new Hashtable<Integer,String>();
	
	data1.put(1,"Jon");
	data1.put(2,"Arya");
	data1.put(3,"sam");
	data1.put(4,"Tom");
	
	System.out.println(data1);
	System.out.println(data1.get(1));
	}
	
	

}
