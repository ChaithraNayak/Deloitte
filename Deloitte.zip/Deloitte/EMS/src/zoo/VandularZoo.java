package zoo;

import org.animals.*;

public class VandularZoo {

	public static void main(String[] args) {
		Lion lion = new Lion();
		System.out.println("\n");
		lion.likeisVegetarian();
		lion.canClimb();
		lion.getSound();
		System.out.println("Color : "+lion.color + "Weight : "+lion.weight + "Age : "+lion.age +"\n");
		
		Monkey monkey =new Monkey();
		System.out.println("\n");
		monkey.likeisVegetarian();
		monkey.canClimb();
		monkey.getSound();
		System.out.println("Color : "+monkey.color + "Weight : "+monkey.weight + "Age : "+monkey.age+"\n");
		
		Elephant elephant = new Elephant();	System.out.println("\n");
		elephant.likeisVegetarian();
		elephant.canClimb();
		elephant.getSound();
		System.out.println("Color : "+elephant.color + "Weight : "+elephant.weight + "Age : "+elephant.age +"\n");
	}
	

}
