package com.customer;





public class MyController {

	public MyController() {
		// TODO Auto-generated constructor stub
	}

}
