package com.deloitte.myAppExceptions;

public class NegativeBillAmountException extends Exception {
	public NegativeBillAmountException() {
		// TODO Auto-generated constructor stub
	}

	public NegativeBillAmountException(String message) {
		super(message);
	}

}
