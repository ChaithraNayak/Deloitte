package com.deloitte.myAppExceptions;

public class InvalidCustomerIdExeption extends Exception {

	public InvalidCustomerIdExeption(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	
}
